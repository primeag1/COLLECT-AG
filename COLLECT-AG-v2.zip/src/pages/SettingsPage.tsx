import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../features/auth/AuthContext';
import { useSettings } from '../hooks/useDB';
import { useSync } from '../services/SyncContext';
import { SyncStatusBar } from '../components/SyncStatusBar';
import { FieldBuilder } from '../features/settings/FieldBuilder';
import { PageHeader, SectionCard, FormRow, Spinner, Toggle } from '../components/ui/index';
import type { AppSettings, PaymentMode } from '../types';
import { SCHEMA_VERSION } from '../config/index';
import { normalizeDefaultRateIds } from '../utils/tax';
import {
  DEFAULT_WA_TEMPLATE as DEFAULT_TEMPLATE,
  WA_PLACEHOLDERS as PLACEHOLDERS,
  WA_TEMPLATE_STORAGE_KEY,
} from '../utils/whatsappTemplate';

// ── Tab system ────────────────────────────────────────────────────────────────

type Tab = 'business' | 'fields' | 'receipt' | 'payments' | 'whatsapp' | 'tax' | 'sync' | 'account';

const TABS: { id: Tab; label: string; emoji: string }[] = [
  { id: 'business',  label: 'Business',       emoji: '🏢' },
  { id: 'fields',    label: 'Member Fields',  emoji: '📋' },
  { id: 'receipt',   label: 'Receipt',        emoji: '🧾' },
  { id: 'payments',  label: 'Payment Modes',  emoji: '💳' },
  { id: 'whatsapp',  label: 'WhatsApp',       emoji: '💬' },
  { id: 'tax',       label: 'Tax',            emoji: '🧮' },
  { id: 'sync',      label: 'Sync & Data',    emoji: '☁️' },
  { id: 'account',   label: 'Account',        emoji: '👤' },
];

// ── Business tab ──────────────────────────────────────────────────────────────

function BusinessTab({ settings, onPatch }: { settings: AppSettings; onPatch: (p: Partial<AppSettings>) => Promise<void> }) {
  const b = settings.business;
  const [form, setForm] = useState({ ...b });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const savedRef = React.useRef(false);
  useEffect(() => {
    if (savedRef.current) return;
    setForm({ ...b });
  }, [settings, b]);

  const set = (key: string, val: string) => setForm(f => ({ ...f, [key]: val }));

  const handleSave = async () => {
    setSaving(true);
    savedRef.current = true;
    try {
      await onPatch({ business: { ...form } });
      setSaved(true);
      setTimeout(() => { savedRef.current = false; setSaved(false); }, 3000);
    } catch {
      savedRef.current = false;
      alert('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const inputS: React.CSSProperties = {
    width: '100%', background: 'var(--color-white)',
    border: '1px solid rgba(20,20,19,0.22)', borderRadius: 10,
    padding: '10px 14px', fontFamily: 'var(--font-sans)',
    fontSize: 14, color: 'var(--color-ink)', outline: 'none', boxSizing: 'border-box',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Business Profile" subtitle="This information appears on your receipts">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 16 }}>
          <FormRow label="Business / Academy Name" required>
            <input style={inputS} value={form.businessName ?? ''} onChange={e => set('businessName', e.target.value)} placeholder="e.g. Sharma Classes" />
          </FormRow>
          <FormRow label="Phone">
            <input style={inputS} value={form.phone ?? ''} onChange={e => set('phone', e.target.value)} placeholder="+91 9876543210" />
          </FormRow>
          <FormRow label="Email">
            <input style={inputS} type="email" value={form.email ?? ''} onChange={e => set('email', e.target.value)} placeholder="contact@yourbusiness.com" />
          </FormRow>
          <FormRow label="Website">
            <input style={inputS} value={form.website ?? ''} onChange={e => set('website', e.target.value)} placeholder="https://yourbusiness.com" />
          </FormRow>
          <FormRow label="GSTIN">
            <input style={inputS} value={form.gstin ?? ''} onChange={e => set('gstin', e.target.value)} placeholder="22AAAAA0000A1Z5" />
          </FormRow>
          <FormRow label="Other Identifier" hint="PAN, shop registration, etc.">
            <input style={inputS} value={form.otherIdentifier ?? ''} onChange={e => set('otherIdentifier', e.target.value)} placeholder="e.g. PAN: ABCDE1234F" />
          </FormRow>
        </div>
        <FormRow label="Address" hint="Appears on receipts">
          <textarea
            style={{ ...inputS, resize: 'vertical', lineHeight: 1.5 }}
            rows={2}
            value={form.address ?? ''}
            onChange={e => set('address', e.target.value)}
            placeholder="Full business address"
          />
        </FormRow>
      </SectionCard>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn-primary" onClick={handleSave} disabled={saving} style={{ padding: '10px 24px', gap: 8 }}>
          {saving ? <><Spinner size={16} /> Saving…</> : 'Save Business Profile'}
        </button>
        {saved && <span style={{ fontSize: 13, color: '#15803d', fontWeight: 600 }}>✓ Saved</span>}
      </div>
    </div>
  );
}

// ── Receipt tab ───────────────────────────────────────────────────────────────

function ReceiptTab({ settings, onPatch }: { settings: AppSettings; onPatch: (p: Partial<AppSettings>) => Promise<void> }) {
  const rn = settings.receiptNumbering;
  const [prefix, setPrefix] = useState(rn.prefix);
  const [includeYear, setIncludeYear] = useState(rn.includeYear);
  const [includeMonth, setIncludeMonth] = useState(rn.includeMonth);
  const [padding, setPadding] = useState(rn.padding);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const receiptSavedRef = React.useRef(false);
  useEffect(() => {
    if (receiptSavedRef.current) return;
    setPrefix(rn.prefix);
    setIncludeYear(rn.includeYear);
    setIncludeMonth(rn.includeMonth);
    setPadding(rn.padding);
  }, [rn.prefix, rn.includeYear, rn.includeMonth, rn.padding]);

  const preview = [
    prefix,
    includeYear  ? new Date().getFullYear().toString() : null,
    includeMonth ? String(new Date().getMonth() + 1).padStart(2, '0') : null,
    '0001'.slice(0, padding).padStart(padding, '0'),
  ].filter(Boolean).join('-');

  const handleSave = async () => {
    setSaving(true);
    receiptSavedRef.current = true;
    try {
      await onPatch({ receiptNumbering: { ...rn, prefix, includeYear, includeMonth, padding } });
      setSaved(true);
      setTimeout(() => { receiptSavedRef.current = false; setSaved(false); }, 3000);
    } catch {
      receiptSavedRef.current = false;
      alert('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const inputS: React.CSSProperties = {
    width: '100%', background: 'var(--color-white)',
    border: '1px solid rgba(20,20,19,0.22)', borderRadius: 10,
    padding: '10px 14px', fontFamily: 'var(--font-sans)',
    fontSize: 14, color: 'var(--color-ink)', outline: 'none', boxSizing: 'border-box',
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Receipt Numbering" subtitle={`Preview: ${preview}`}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }}>
          <FormRow label="Prefix" required>
            <input style={inputS} value={prefix} onChange={e => setPrefix(e.target.value.toUpperCase())} placeholder="FEE" maxLength={10} />
          </FormRow>
          <FormRow label="Number padding" hint="Digits in the serial (e.g. 4 → 0001)">
            <select style={{ ...inputS, cursor: 'pointer' }} value={padding} onChange={e => setPadding(Number(e.target.value))}>
              {[3, 4, 5, 6].map(n => <option key={n} value={n}>{n} digits ({String(1).padStart(n, '0')})</option>)}
            </select>
          </FormRow>
          <FormRow label="Include year">
            <Toggle checked={includeYear} onChange={setIncludeYear} label={includeYear ? 'Yes' : 'No'} />
          </FormRow>
          <FormRow label="Include month">
            <Toggle checked={includeMonth} onChange={setIncludeMonth} label={includeMonth ? 'Yes' : 'No'} />
          </FormRow>
        </div>
        <div style={{ marginTop: 16, background: 'var(--color-canvas)', borderRadius: 10, padding: '12px 16px', display: 'inline-block' }}>
          <p style={{ fontSize: 12, color: 'var(--color-slate)', marginBottom: 4 }}>Receipt number preview</p>
          <p style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.01em', color: 'var(--color-ink)' }}>{preview}</p>
        </div>
      </SectionCard>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn-primary" onClick={handleSave} disabled={saving} style={{ padding: '10px 24px', gap: 8 }}>
          {saving ? <><Spinner size={16} /> Saving…</> : 'Save Receipt Settings'}
        </button>
        {saved && <span style={{ fontSize: 13, color: '#15803d', fontWeight: 600 }}>✓ Saved</span>}
      </div>
    </div>
  );
}

// ── Payment modes tab ─────────────────────────────────────────────────────────

function PaymentModesTab({ settings, onPatch }: { settings: AppSettings; onPatch: (p: Partial<AppSettings>) => Promise<void> }) {
  const [modes, setModes] = useState<PaymentMode[]>(settings.paymentModes);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [newLabel, setNewLabel] = useState('');

  const modesSavedRef = React.useRef(false);
  useEffect(() => {
    if (modesSavedRef.current) return;
    setModes(settings.paymentModes);
  }, [settings]);

  const toggle = (id: string, enabled: boolean) =>
    setModes(m => m.map(p => p.id === id ? { ...p, enabled } : p));

  const addMode = () => {
    if (!newLabel.trim()) return;
    const id = newLabel.trim().toLowerCase().replace(/\s+/g, '_');
    setModes(m => [...m, { id, label: newLabel.trim(), enabled: true, order: m.length }]);
    setNewLabel('');
  };

  const handleSave = async () => {
    setSaving(true);
    modesSavedRef.current = true;
    try {
      await onPatch({ paymentModes: modes });
      setSaved(true);
      setTimeout(() => { modesSavedRef.current = false; setSaved(false); }, 3000);
    } catch {
      modesSavedRef.current = false;
      alert('Failed to save. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Payment Modes" subtitle="Enable the modes you accept">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0, border: '1px solid var(--color-dust)', borderRadius: 12, overflow: 'hidden' }}>
          {modes.map(mode => (
            <div key={mode.id} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '12px 16px', borderBottom: '1px solid var(--color-dust)',
              background: mode.enabled ? 'var(--color-white)' : 'var(--color-canvas)',
            }}>
              <span style={{ fontSize: 14, fontWeight: 500, color: 'var(--color-ink)' }}>{mode.label}</span>
              <Toggle checked={mode.enabled} onChange={v => toggle(mode.id, v)} size="sm" />
            </div>
          ))}
          {/* Add new */}
          <div style={{ display: 'flex', gap: 8, padding: 12, background: 'var(--color-canvas)' }}>
            <input
              style={{ flex: 1, background: 'var(--color-white)', border: '1px solid rgba(20,20,19,0.22)', borderRadius: 8, padding: '8px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, outline: 'none' }}
              value={newLabel}
              onChange={e => setNewLabel(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addMode(); } }}
              placeholder="Add new payment mode…"
            />
            <button
              onClick={addMode}
              style={{ background: 'var(--color-ink)', color: 'var(--color-canvas)', border: 'none', borderRadius: 8, padding: '0 16px', cursor: 'pointer', fontSize: 18, fontWeight: 300 }}
            >+</button>
          </div>
        </div>
      </SectionCard>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn-primary" onClick={handleSave} disabled={saving} style={{ padding: '10px 24px', gap: 8 }}>
          {saving ? <><Spinner size={16} /> Saving…</> : 'Save Payment Modes'}
        </button>
        {saved && <span style={{ fontSize: 13, color: '#15803d', fontWeight: 600 }}>✓ Saved</span>}
      </div>
    </div>
  );
}

// ── WhatsApp tab ──────────────────────────────────────────────────────────────
// Default text and placeholder list live in src/utils/whatsappTemplate.ts so
// the member profile's "Send WhatsApp reminder" button always matches what's
// shown/saved here.

function WhatsAppTab() {
  const [template, setTemplate] = useState(DEFAULT_TEMPLATE);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    localStorage.setItem(WA_TEMPLATE_STORAGE_KEY, template);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  useEffect(() => {
    const stored = localStorage.getItem(WA_TEMPLATE_STORAGE_KEY);
    if (stored) setTemplate(stored);
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard
        title="WhatsApp Reminder Template"
        subtitle="When you send a reminder, this message is pre-filled with the member's details"
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 4 }}>
            {PLACEHOLDERS.map(p => (
              <button
                key={p.key}
                onClick={() => setTemplate(t => t + p.key)}
                title={p.desc}
                style={{
                  background: 'var(--color-bone)', border: '1px solid var(--color-dust)',
                  borderRadius: 8, padding: '4px 10px', cursor: 'pointer',
                  fontSize: 12, fontWeight: 600, color: 'var(--color-ink)',
                  fontFamily: 'var(--font-sans)',
                }}
              >
                {p.key}
              </button>
            ))}
          </div>
          <textarea
            style={{
              width: '100%', minHeight: 200,
              background: 'var(--color-white)',
              border: '1px solid rgba(20,20,19,0.22)', borderRadius: 12,
              padding: '12px 14px', fontFamily: 'var(--font-sans)',
              fontSize: 14, lineHeight: 1.7, color: 'var(--color-ink)',
              outline: 'none', resize: 'vertical', boxSizing: 'border-box',
            }}
            value={template}
            onChange={e => setTemplate(e.target.value)}
          />
          <p style={{ fontSize: 12, color: 'var(--color-slate)', lineHeight: 1.6 }}>
            Click a placeholder above to insert it. When you tap "Send WhatsApp reminder" on a member's profile,
            COLLECT-AG will replace these placeholders with real values and open WhatsApp with the message pre-filled.
            <strong> You always send it manually</strong> — COLLECT-AG never sends messages on your behalf.
          </p>
        </div>
      </SectionCard>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn-primary" onClick={handleSave} style={{ padding: '10px 24px' }}>
          Save Template
        </button>
        {saved && <span style={{ fontSize: 13, color: '#15803d', fontWeight: 600 }}>✓ Saved</span>}
      </div>
    </div>
  );
}


// ── Sync tab ──────────────────────────────────────────────────────────────────

function SyncTab() {
  const { syncState, push, pull, pendingCount, hasPendingChanges, connectDrive } = useSync();
  const [pushing, setPushing]     = useState(false);
  const [pulling, setPulling]     = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [msg, setMsg]             = useState('');
  const [msgType, setMsgType]     = useState<'ok'|'err'>('ok');

  const showMsg = (text: string, type: 'ok'|'err' = 'ok') => {
    setMsg(text); setMsgType(type);
    setTimeout(() => setMsg(''), 5000);
  };

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const ok = await connectDrive();
      if (ok) showMsg('Google Drive connected. Your data is syncing now.', 'ok');
      else showMsg('Connection was cancelled or blocked. Please try again.', 'err');
    } catch {
      showMsg('Could not connect to Google Drive. Please try again.', 'err');
    } finally {
      setConnecting(false);
    }
  };

  const handlePush = async () => {
    setPushing(true);
    try {
      await push();
      showMsg('All data saved to your Google Drive.', 'ok');
    } catch {
      showMsg('Sync failed. Check your internet connection.', 'err');
    } finally { setPushing(false); }
  };

  const handlePull = async () => {
    if (!confirm('This will restore data from Google Drive into this device. Local changes not yet synced will be overwritten. Continue?')) return;
    setPulling(true);
    try {
      await pull();
      showMsg('Data restored from your Google Drive.', 'ok');
    } catch {
      showMsg('Restore failed. Check your internet connection.', 'err');
    } finally { setPulling(false); }
  };

  const [checkingBatches, setCheckingBatches] = useState(false);

  const handleCheckBatches = async () => {
    setCheckingBatches(true);
    try {
      const { processExpiredBatchMemberships } = await import('../db/repositories/batchLifecycle');
      const result = await processExpiredBatchMemberships(true); // force = bypass once-per-day guard
      if (result.batchesProcessed === 0) {
        showMsg('No expired batches found. Everything is up to date.', 'ok');
      } else {
        showMsg(
          `Processed ${result.batchesProcessed} ended batch${result.batchesProcessed !== 1 ? 'es' : ''} — ` +
          `${result.membershipsEnded} membership${result.membershipsEnded !== 1 ? 's' : ''} ended, ` +
          `${result.studentsCompleted} member${result.studentsCompleted !== 1 ? 's' : ''} marked completed.`,
          'ok'
        );
      }
    } catch {
      showMsg('Check failed. Please try again.', 'err');
    } finally {
      setCheckingBatches(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Drive Sync Status" subtitle="Your data is stored in your Google Drive">
        <div style={{ marginBottom: 16 }}>
          <SyncStatusBar />
        </div>

        {hasPendingChanges && syncState !== 'syncing' && (
          <div style={{ background: 'rgba(243,115,56,0.08)', border: '1px solid rgba(243,115,56,0.2)', borderRadius: 10, padding: '10px 14px', marginBottom: 12 }}>
            <p style={{ fontSize: 13, color: 'var(--color-signal)', fontWeight: 500 }}>
              {pendingCount > 0 ? `${pendingCount} change${pendingCount !== 1 ? 's' : ''} waiting to sync.` : 'Last sync had an error — tap Sync now to retry.'}
            </p>
          </div>
        )}

        {msg && (
          <div style={{ background: msgType === 'ok' ? 'rgba(34,197,94,0.08)' : 'rgba(239,68,68,0.08)', border: `1px solid ${msgType === 'ok' ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)'}`, borderRadius: 10, padding: '10px 14px', marginBottom: 12 }}>
            <p style={{ fontSize: 13, color: msgType === 'ok' ? '#15803d' : '#b91c1c' }}>{msg}</p>
          </div>
        )}

        {syncState === 'no_drive' ? (
          <button className="btn-primary" onClick={handleConnect} disabled={connecting}
            style={{ padding: '11px 24px', fontSize: 14, gap: 8 }}>
            {connecting ? <><Spinner size={14} /> Connecting…</> : '🔗 Connect Google Drive'}
          </button>
        ) : (
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <button className="btn-primary" onClick={handlePush}
              disabled={pushing || syncState === 'syncing'}
              style={{ padding: '10px 22px', fontSize: 14, gap: 8 }}>
              {pushing ? <><Spinner size={14} /> Saving…</> : '☁️ Save to Drive now'}
            </button>
            <button className="btn-secondary" onClick={handlePull}
              disabled={pulling || syncState === 'syncing'}
              style={{ padding: '10px 22px', fontSize: 14, gap: 8 }}>
              {pulling ? <><Spinner size={14} /> Restoring…</> : '⬇ Restore from Drive'}
            </button>
          </div>
        )}
      </SectionCard>

      <SectionCard title="Batch Lifecycle" subtitle="Automatically ends memberships and deactivates members when a batch's end date passes">
        <p style={{ fontSize: 14, color: 'var(--color-charcoal)', lineHeight: 1.7, marginBottom: 14 }}>
          COLLECT-AG checks once a day automatically: any batch whose <strong>End Date</strong> has passed
          has its members' batch membership marked complete. A member with no other active batch is then
          marked <strong>Inactive</strong> — their record and payment history stay fully visible under the
          "Inactive" or "All" filter in Members.
        </p>
        <button className="btn-secondary" onClick={handleCheckBatches} disabled={checkingBatches} style={{ fontSize: 13, padding: '9px 18px', gap: 8 }}>
          {checkingBatches ? <><Spinner size={14} /> Checking…</> : '🔁 Check expired batches now'}
        </button>
      </SectionCard>

      <SectionCard title="Data Location" subtitle="Where your COLLECT-AG data lives in Google Drive">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {[
            { icon: '📁', label: 'Root folder',  path: 'My Drive / COLLECT-AG /' },
            { icon: '🗃️', label: 'Data files',   path: 'COLLECT-AG / Data /' },
            { icon: '🧾', label: 'Receipt PDFs', path: 'COLLECT-AG / Receipts / YYYY /' },
            { icon: '📤', label: 'Exports',       path: 'COLLECT-AG / Exports /' },
          ].map((item, i, arr) => (
            <div key={item.label} style={{ display: 'flex', gap: 12, alignItems: 'center', padding: '11px 0', borderBottom: i < arr.length - 1 ? '1px solid var(--color-dust)' : 'none' }}>
              <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
              <div>
                <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--color-ink)', marginBottom: 2 }}>{item.label}</p>
                <p style={{ fontSize: 12, color: 'var(--color-slate)', fontFamily: 'monospace' }}>{item.path}</p>
              </div>
            </div>
          ))}
        </div>
        <p style={{ marginTop: 14, fontSize: 13, color: 'var(--color-slate)', lineHeight: 1.65 }}>
          To permanently delete your data, delete the <strong>COLLECT-AG</strong> folder from your Google Drive.
          COLLECT-AG only accesses files it created — it cannot read any other Drive files.
        </p>
      </SectionCard>

      <SectionCard title="Sync Behaviour" subtitle="How COLLECT-AG keeps your data safe">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { icon: '⚡', text: 'Syncs immediately after each payment is recorded' },
            { icon: '⏱️', text: 'Auto-syncs every 5 minutes while the app is open' },
            { icon: '👁️', text: 'Syncs when you switch back to the app after 2+ minutes away' },
            { icon: '📶', text: 'Works offline — changes are saved locally and sync when back online' },
            { icon: '🔄', text: 'Retries automatically with increasing delays if sync fails (up to 3 times)' },
            { icon: '🖥️', text: 'Restores your data from Drive when you sign in on a new device' },
            { icon: '🛡️', text: 'Each data file includes a version stamp to detect schema changes' },
          ].map(item => (
            <div key={item.text} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <span style={{ fontSize: 15, flexShrink: 0, marginTop: 1 }}>{item.icon}</span>
              <p style={{ fontSize: 14, color: 'var(--color-charcoal)', lineHeight: 1.5 }}>{item.text}</p>
            </div>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Conflict Handling" subtitle="What happens if you use two devices">
        <p style={{ fontSize: 14, color: 'var(--color-charcoal)', lineHeight: 1.7, marginBottom: 12 }}>
          COLLECT-AG uses a <strong>last-write-wins</strong> strategy.
          Each sync writes a full snapshot of your data to Drive.
          If you use two devices and make changes on both while offline,
          whichever device syncs last will overwrite the other.
        </p>
        <p style={{ fontSize: 14, color: 'var(--color-charcoal)', lineHeight: 1.7 }}>
          <strong>Best practice:</strong> always tap "Save to Drive now" before switching devices,
          and "Restore from Drive" when opening on a second device after a gap.
          For a single-device workflow, the automatic sync is sufficient.
        </p>
      </SectionCard>
    </div>
  );
}


// ── Tax Tab ───────────────────────────────────────────────────────────────────

function TaxTab({ settings, onPatch }: { settings: AppSettings; onPatch: (p: Partial<AppSettings>) => Promise<void> }) {
  const normaliseTax = (t: AppSettings['taxSettings']) => {
    if (!t) return { enabled: false, rates: [], defaultRateIds: [], amountIsInclusive: false };
    return { ...t, defaultRateIds: normalizeDefaultRateIds(t) };
  };
  const [tax, setTax] = useState(() => normaliseTax(settings.taxSettings));
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [newRateName, setNewRateName] = useState('');
  const [newRateValue, setNewRateValue] = useState('');

  const taxSavedRef = React.useRef(false);
  React.useEffect(() => {
    if (taxSavedRef.current) return;
    setTax(normaliseTax(settings.taxSettings));
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    taxSavedRef.current = true;
    try {
      await onPatch({ taxSettings: tax });
      setSaved(true);
      setTimeout(() => { taxSavedRef.current = false; setSaved(false); }, 3000);
    } catch {
      taxSavedRef.current = false;
      alert('Failed to save tax settings. Please try again.');
    } finally { setSaving(false); }
  };

  const addRate = () => {
    const v = parseFloat(newRateValue);
    if (!newRateName.trim() || isNaN(v) || v <= 0) return;
    const newRate: import('../types').TaxRate = {
      id: `tax_${Date.now()}`,
      name: newRateName.trim(),
      rate: v,
      enabled: true,
    };
    setTax(t => ({ ...t, rates: [...t.rates, newRate] }));
    setNewRateName('');
    setNewRateValue('');
  };

  const removeRate = (id: string) => setTax(t => ({
    ...t,
    rates: t.rates.filter(r => r.id !== id),
    defaultRateIds: t.defaultRateIds.filter(rid => rid !== id),
  }));

  const toggleDefault = (id: string) => setTax(t => ({
    ...t,
    defaultRateIds: t.defaultRateIds.includes(id)
      ? t.defaultRateIds.filter(rid => rid !== id)
      : [...t.defaultRateIds, id],
  }));

  const IS: React.CSSProperties = {
    background: 'var(--color-white)', border: '1px solid rgba(20,20,19,0.22)',
    borderRadius: 10, padding: '9px 12px', fontFamily: 'var(--font-sans)',
    fontSize: 14, color: 'var(--color-ink)', outline: 'none', boxSizing: 'border-box' as const,
  };

  const totalDefaultPct = tax.rates
    .filter(r => tax.defaultRateIds.includes(r.id))
    .reduce((s, r) => s + r.rate, 0);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Tax / GST Settings" subtitle="Configure tax rates for your invoices">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          <FormRow label="Enable Tax on Invoices">
            <Toggle checked={tax.enabled} onChange={v => setTax(t => ({ ...t, enabled: v }))}
              label={tax.enabled ? 'Enabled' : 'Disabled'} />
          </FormRow>

          {tax.enabled && (
            <>
              <FormRow label="Amount Entry" hint="Whether the amount typed at payment time already includes tax, or tax is added on top">
                <div style={{ display: 'flex', gap: 10 }}>
                  {[
                    { label: 'Exclusive — tax added on top', value: false },
                    { label: 'Inclusive — amount already includes tax', value: true },
                  ].map(opt => (
                    <button key={String(opt.value)} type="button"
                      onClick={() => setTax(t => ({ ...t, amountIsInclusive: opt.value }))}
                      style={{
                        flex: 1, padding: '9px 12px', borderRadius: 10,
                        border: `1.5px solid ${tax.amountIsInclusive === opt.value ? 'var(--color-ink)' : 'var(--color-dust)'}`,
                        background: tax.amountIsInclusive === opt.value ? 'var(--color-ink)' : 'var(--color-white)',
                        color: tax.amountIsInclusive === opt.value ? 'var(--color-canvas)' : 'var(--color-ink)',
                        fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
                      }}>
                      {opt.label}
                    </button>
                  ))}
                </div>
              </FormRow>

              <FormRow label="Tax Rates" hint="Add the tax rates you use, e.g. CGST 9%, SGST 9%, or a single GST 18%">
                <div style={{ display: 'flex', flexDirection: 'column', gap: 0, border: '1px solid var(--color-dust)', borderRadius: 12, overflow: 'hidden', marginBottom: 8 }}>
                  {tax.rates.length === 0 && (
                    <p style={{ padding: '12px 16px', fontSize: 13, color: 'var(--color-dust)' }}>No tax rates added yet.</p>
                  )}
                  {tax.rates.map((rate, i) => (
                    <div key={rate.id} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '10px 14px',
                      borderBottom: i < tax.rates.length - 1 ? '1px solid var(--color-dust)' : 'none',
                      background: 'var(--color-white)',
                    }}>
                      <div>
                        <p style={{ fontSize: 14, fontWeight: 600, color: 'var(--color-ink)' }}>{rate.name}</p>
                        <p style={{ fontSize: 12, color: 'var(--color-slate)' }}>{rate.rate}%</p>
                      </div>
                      <button onClick={() => removeRate(rate.id)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: 'var(--color-dust)', padding: '4px 8px' }}>
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input style={{ ...IS, flex: 2 }} value={newRateName} onChange={e => setNewRateName(e.target.value)}
                    placeholder="Name (e.g. CGST, SGST, GST)" />
                  <input style={{ ...IS, flex: 1 }} type="number" value={newRateValue} onChange={e => setNewRateValue(e.target.value)}
                    placeholder="%" min="0" max="100" />
                  <button onClick={addRate} className="btn-primary" style={{ padding: '0 16px', fontSize: 14, whiteSpace: 'nowrap' }}>
                    + Add
                  </button>
                </div>
              </FormRow>

              {tax.rates.length > 0 && (
                <FormRow
                  label="Default Tax Rates"
                  hint="Select one or more rates to apply automatically to new payments (e.g. tick both CGST and SGST). Each appears as a separate line on the receipt. You can still change this per payment."
                >
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                    {tax.rates.map(rate => {
                      const active = tax.defaultRateIds.includes(rate.id);
                      return (
                        <button key={rate.id} type="button" onClick={() => toggleDefault(rate.id)}
                          style={{
                            padding: '8px 16px', borderRadius: 999,
                            border: `1.5px solid ${active ? 'var(--color-ink)' : 'var(--color-dust)'}`,
                            background: active ? 'var(--color-ink)' : 'var(--color-white)',
                            color: active ? 'var(--color-canvas)' : 'var(--color-ink)',
                            fontSize: 13, fontWeight: active ? 600 : 400,
                            cursor: 'pointer', fontFamily: 'var(--font-sans)',
                            transition: 'all 0.15s ease',
                          }}>
                          {active ? '✓ ' : ''}{rate.name} ({rate.rate}%)
                        </button>
                      );
                    })}
                  </div>
                  {tax.defaultRateIds.length > 0 && (
                    <p style={{ fontSize: 12, color: 'var(--color-slate)', marginTop: 10 }}>
                      Default total: <strong>{totalDefaultPct}%</strong> across {tax.defaultRateIds.length} rate{tax.defaultRateIds.length !== 1 ? 's' : ''}
                    </p>
                  )}
                  {tax.defaultRateIds.length === 0 && (
                    <p style={{ fontSize: 12, color: 'var(--color-slate)', marginTop: 10 }}>
                      No default set — you'll be asked to pick a tax rate manually on each payment.
                    </p>
                  )}
                </FormRow>
              )}
            </>
          )}
        </div>
      </SectionCard>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button className="btn-primary" onClick={handleSave} disabled={saving} style={{ padding: '10px 24px', gap: 8 }}>
          {saving ? <><Spinner size={16} /> Saving…</> : 'Save Tax Settings'}
        </button>
        {saved && <span style={{ fontSize: 13, color: '#15803d', fontWeight: 600 }}>✓ Saved</span>}
      </div>
    </div>
  );
}

// ── Account Tab ────────────────────────────────────────────────────────────────

function AccountTab() {
  const { user, signOut, ensureFreshToken } = useAuth();
  const navigate = useNavigate();
  const [deleting, setDeleting] = useState(false);
  const [confirm, setConfirm] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [msg, setMsg] = useState('');
  const [backupMsg, setBackupMsg] = useState('');
  const [downloadingBackup, setDownloadingBackup] = useState(false);

  const handleDownloadBackup = async () => {
    setDownloadingBackup(true);
    setBackupMsg('');
    try {
      const { getDB } = await import('../db/indexeddb/database');
      const db = getDB();
      const [
        students, batches, subjects, academicYears, payments, receipts,
        feeSchedules, studentFields, paymentFields, receiptTemplates, settings,
      ] = await Promise.all([
        db.students.toArray(),
        db.batches.toArray(),
        db.subjects.toArray(),
        db.academicYears.toArray(),
        db.payments.toArray(),
        db.receipts.toArray(),
        db.feeSchedules.toArray(),
        db.studentFields.toArray(),
        db.paymentFields.toArray(),
        db.receiptTemplates.toArray(),
        db.settings.get('singleton'),
      ]);
      const payload = {
        schemaVersion: SCHEMA_VERSION,
        exportedAt: new Date().toISOString(),
        data: {
          students, batches, subjects, academicYears, payments, receipts,
          feeSchedules, studentFields, paymentFields, receiptTemplates, settings,
        },
      };
      const url = URL.createObjectURL(
        new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }),
      );
      const link = document.createElement('a');
      link.href = url;
      link.download = `collect-ag-backup-${new Date().toISOString().replaceAll(':', '-')}.json`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setBackupMsg('Backup downloaded.');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      setBackupMsg(`Backup download failed: ${message}`);
    } finally {
      setDownloadingBackup(false);
    }
  };

  const handleDeleteAll = async () => {
    if (confirm !== 'DELETE') return;
    setDeleting(true);
    try {
      const freshToken = await ensureFreshToken();
      if (!freshToken) {
        throw new Error('Google Drive access is required. Your local data was not deleted.');
      }

      const { driveMetaRepository } = await import('../db/repositories/syncRepository');
      const { driveClient } = await import('../services/google/driveClient');
      const meta = await driveMetaRepository.get();
      let rootFolderIds = meta.applicationRootFolderId
        ? [meta.applicationRootFolderId]
        : [];
      if (rootFolderIds.length === 0) {
        let folders = await driveClient.listFiles(
          freshToken,
          "name='COLLECT-AG' and mimeType='application/vnd.google-apps.folder' and trashed=false",
          'files(id,name)',
        );
        if (folders.length === 0) {
          folders = await driveClient.listFiles(
            freshToken,
            "name='FeeLedger' and mimeType='application/vnd.google-apps.folder' and trashed=false",
            'files(id,name)',
          );
        }
        rootFolderIds = folders.map(folder => folder.id);
      }
      await Promise.all(rootFolderIds.map(folderId => driveClient.trashFile(freshToken, folderId)));

      await signOut(true);
      navigate('/', { replace: true });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      setMsg(`COLLECT-AG could not delete your data. ${message}`);
      setDeleting(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <SectionCard title="Your Account" subtitle="Signed in via Google">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '8px 0' }}>
          {user?.photoUrl && (
            <img src={user.photoUrl} alt={user.displayName ?? 'User'} style={{ width: 48, height: 48, borderRadius: '50%', objectFit: 'cover' }} />
          )}
          <div>
            <p style={{ fontSize: 15, fontWeight: 700, color: 'var(--color-ink)' }}>{user?.displayName ?? 'User'}</p>
            <p style={{ fontSize: 13, color: 'var(--color-slate)' }}>{user?.email}</p>
          </div>
        </div>
        <button className="btn-secondary" onClick={async () => { await signOut(); navigate('/', { replace: true }); }}
          style={{ marginTop: 16, fontSize: 14, padding: '9px 20px' }}>
          Sign out
        </button>
      </SectionCard>

      <SectionCard title="Delete All Data" subtitle="Move your Drive data to Trash, clear this device, and sign out">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <p style={{ fontSize: 14, color: 'var(--color-charcoal)', lineHeight: 1.7 }}>
            Download a JSON backup before deleting if you want to keep a copy. Delete All moves the
            <strong> COLLECT-AG</strong> folder to your Google Drive Trash and clears this device.
          </p>
          <p style={{ fontSize: 13, color: 'var(--color-slate)', lineHeight: 1.6 }}>
            Note: This removes your data from Drive and signs you out of COLLECT-AG.
            To revoke COLLECT-AG's Google account access entirely, visit{' '}
            <a href="https://myaccount.google.com/permissions" target="_blank" rel="noopener noreferrer"
              style={{ color: 'var(--color-link)' }}>
              myaccount.google.com/permissions
            </a>{' '}
            and remove COLLECT-AG (the Google consent screen may still show its previous name).
          </p>

          <div>
            <button className="btn-secondary" onClick={handleDownloadBackup} disabled={downloadingBackup}
              style={{ fontSize: 14, padding: '9px 20px' }}>
              {downloadingBackup ? 'Preparing backup…' : 'Download backup (JSON)'}
            </button>
            {backupMsg && <p role="status" aria-live="polite" aria-atomic="true" style={{ fontSize: 12, color: backupMsg.startsWith('Backup download failed') ? '#b91c1c' : '#15803d', marginTop: 8 }}>{backupMsg}</p>}
          </div>

          {!showConfirm ? (
            <button onClick={() => setShowConfirm(true)}
              style={{ display: 'inline-flex', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)', borderRadius: 10, padding: '10px 20px', cursor: 'pointer', fontSize: 14, color: '#b91c1c', fontFamily: 'var(--font-sans)', fontWeight: 600 }}>
              Delete all my data…
            </button>
          ) : (
            <div style={{ background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 14, padding: 20 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: '#b91c1c', marginBottom: 12 }}>
                Type DELETE to move the Drive folder to Trash and clear this device:
              </p>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                <input
                  value={confirm} onChange={e => setConfirm(e.target.value)}
                  placeholder="Type DELETE"
                  style={{ flex: 1, minWidth: 140, background: 'var(--color-white)', border: '1px solid rgba(239,68,68,0.4)', borderRadius: 8, padding: '9px 12px', fontFamily: 'var(--font-sans)', fontSize: 14, outline: 'none' }}
                />
                <button onClick={handleDeleteAll} disabled={confirm !== 'DELETE' || deleting}
                  style={{ background: confirm === 'DELETE' ? '#b91c1c' : 'var(--color-dust)', color: 'white', border: 'none', borderRadius: 8, padding: '9px 18px', cursor: confirm === 'DELETE' ? 'pointer' : 'not-allowed', fontSize: 14, fontFamily: 'var(--font-sans)', fontWeight: 600 }}>
                  {deleting ? 'Deleting…' : 'Move to Trash & Delete'}
                </button>
                <button onClick={() => { setShowConfirm(false); setConfirm(''); }}
                  style={{ background: 'none', border: '1px solid var(--color-dust)', borderRadius: 8, padding: '9px 14px', cursor: 'pointer', fontSize: 14, fontFamily: 'var(--font-sans)', color: 'var(--color-slate)' }}>
                  Cancel
                </button>
              </div>
              {msg && <p style={{ fontSize: 12, color: '#b91c1c', marginTop: 10 }}>{msg}</p>}
            </div>
          )}
        </div>
      </SectionCard>
    </div>
  );
}

// ── Main Settings page ────────────────────────────────────────────────────────

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('business');
  const { data: settings, loading, patch } = useSettings();

  if (loading || !settings) {
    return (
      <div style={{ padding: 32, display: 'flex', justifyContent: 'center' }}>
        <Spinner size={32} />
      </div>
    );
  }

  return (
    <div style={{ padding: 'clamp(16px, 3vw, 32px)', maxWidth: 860, margin: '0 auto' }}>
      <PageHeader
        eyebrow="Configuration"
        title="Settings"
        subtitle="Customise COLLECT-AG for your business"
      />

      {/* Tab bar */}
      <div style={{
        display: 'flex', gap: 4, flexWrap: 'wrap',
        background: 'var(--color-white)',
        border: '1px solid var(--color-dust)',
        borderRadius: 16, padding: 6, marginBottom: 28,
      }}>
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              flex: '1 1 auto',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              padding: '8px 14px',
              border: 'none', borderRadius: 12,
              background: activeTab === tab.id ? 'var(--color-ink)' : 'transparent',
              color: activeTab === tab.id ? 'var(--color-canvas)' : 'var(--color-slate)',
              fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600,
              cursor: 'pointer', transition: 'all 0.15s ease', whiteSpace: 'nowrap',
            }}
          >
            <span>{tab.emoji}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'business' && <BusinessTab settings={settings} onPatch={patch} />}
      {activeTab === 'fields'   && <FieldBuilder />}
      {activeTab === 'receipt'  && <ReceiptTab   settings={settings} onPatch={patch} />}
      {activeTab === 'payments' && <PaymentModesTab settings={settings} onPatch={patch} />}
      {activeTab === 'whatsapp' && <WhatsAppTab />}
      {activeTab === 'tax'     && <TaxTab settings={settings} onPatch={patch} />}
      {activeTab === 'sync'     && <SyncTab />}
      {activeTab === 'account'  && <AccountTab />}
    </div>
  );
}

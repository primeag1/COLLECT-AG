import React, {
  createContext, useContext, useEffect,
  useState, useCallback, useRef,
} from 'react';
import type { AppUser } from '../../types';
import { driveMetaRepository } from '../../db/repositories/syncRepository';
import {
  DRIVE_FILE_SCOPE,
  REDIRECT_STATE_SESSION_KEY,
  finalizeSignOut,
  generateOAuthState,
  parseOAuthRedirect,
  verifyGoogleAccessToken,
} from './authSecurity';

// ── Types ────────────────────────────────────────────────────────────────────

interface AuthState {
  user: AppUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  authError: string | null;
  hasDriveAccess: boolean;
  gisReady: boolean;
}

interface AuthContextValue extends AuthState {
  signIn: () => void;
  signOut: (removeLocalData?: boolean) => Promise<void>;
  requestDriveAccess: () => Promise<boolean>;
  /**
   * Same as requestDriveAccess, but forces Google to show a visible consent
   * dialog every time (prompt: 'consent'), rather than attempting a silent
   * grant first. Use this for direct, explicit user actions like a "Connect
   * Drive" button click, where we want a guaranteed, visible outcome instead
   * of a request that might silently no-op.
   */
  connectDriveInteractive: () => Promise<boolean>;
  /**
   * Standalone-PWA only: if the token has expired and we have a prior
   * session to silently restore, starts a redirect-based reconnect and
   * returns true (caller should stop — the page is about to unload).
   * Returns false if there's nothing to do (token still valid, not
   * standalone, no prior session, or already tried once this tab session).
   * Intended only for "app opened/resumed" moments — see the function's
   * own comment for why it's not wired into every token check.
   */
  attemptSilentReconnect: () => boolean;
  /**
   * Returns a Drive access token guaranteed to be valid for at least a
   * couple more minutes, refreshing it silently first if the current one
   * is missing, expired, or about to expire. Returns null if no token
   * could be obtained (caller should treat this as "no Drive access").
   */
  ensureFreshToken: () => Promise<string | null>;
}

// ── GIS window types ─────────────────────────────────────────────────────────

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: object) => void;
          prompt: (cb?: (n: GisNotification) => void) => void;
          renderButton: (el: HTMLElement, config: object) => void;
          disableAutoSelect: () => void;
          cancel: () => void;
        };
        oauth2: {
          initTokenClient: (config: object) => TokenClient;
          revoke?: (token: string, callback?: () => void) => void;
        };
      };
    };
  }
}

interface GisNotification {
  isNotDisplayed: () => boolean;
  isSkippedMoment: () => boolean;
  getNotDisplayedReason: () => string;
  getDismissedReason: () => string;
}

interface TokenClient {
  requestAccessToken: (cfg?: { prompt?: string }) => void;
}

interface GoogleCredentialResponse {
  credential: string;
}

interface GoogleTokenResponse {
  access_token: string;
  expires_in?: number; // seconds, typically 3599
  error?: string;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function parseJwt(token: string): Record<string, unknown> {
  try {
    const payload = token.split('.')[1];
    if (!payload) return {};
    const b64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(b64));
  } catch {
    return {};
  }
}

function buildUser(credential: string): AppUser {
  const p = parseJwt(credential);
  const now = new Date().toISOString();
  return {
    id: (p.sub as string) ?? crypto.randomUUID(),
    googleSubjectId: p.sub as string | undefined,
    email: p.email as string | undefined,
    displayName: p.name as string | undefined,
    photoUrl: p.picture as string | undefined,
    createdAt: now,
    updatedAt: now,
  };
}

// Only identity/session intent is persisted. OAuth access tokens remain in memory.
const SESSION_USER_KEY   = 'fl_user';
const HAD_SESSION_KEY    = 'fl_had_session';
const STORAGE = localStorage;
STORAGE.removeItem('fl_token');
STORAGE.removeItem('fl_token_expires_at');

// Refresh proactively if less than this many ms remain on the token.
const REFRESH_BUFFER_MS = 3 * 60 * 1000; // 3 minutes
const DEFAULT_TOKEN_LIFETIME_S = 3600;

function isTokenValid(expiresAt: number | null): boolean {
  return !!expiresAt && Date.now() < expiresAt - REFRESH_BUFFER_MS;
}

// ── Standalone-PWA reauth (redirect-based) ───────────────────────────────
//
// `requestDriveAndIdentify`, `requestDriveAccess` and `connectDriveInteractive`
// (below) all use Google's popup-based OAuth2 token client. That works fine
// in a normal browser tab, but when COLLECT-AG is installed and launched as a
// standalone PWA on Android, the popup it opens loses its `window.opener`
// link back to this page, so the token callback never fires — this is what
// caused "Sync now" to do nothing, and silent background refreshes to fail
// after the ~1hr access token expired. There's no refresh token available in
// a backend-less app, so once the token expires, some kind of fresh round
// trip to Google is unavoidable — we just do it via a full-page redirect
// instead of a popup when running standalone, since redirects aren't subject
// to the same opener restrictions.

const OAUTH_AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
// Set right before an *automatic* (non-tap) silent reconnect redirect, so we
// only ever attempt one per tab session — if it comes back with an error
// (session truly gone / revoked), we don't redirect-loop, we just fall back
// to the manual "Connect Drive" button.
const AUTO_REAUTH_GUARD_KEY = 'fl_auto_reauth_attempted';
const OAUTH_SCOPES = [
  'openid',
  'email',
  'profile',
  DRIVE_FILE_SCOPE,
].join(' ');

function isStandalonePWA(): boolean {
  try {
    if (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) return true;
    if (window.matchMedia && window.matchMedia('(display-mode: minimal-ui)').matches) return true;
    // iOS "Add to Home Screen" flag — harmless to also check here.
    return (window.navigator as unknown as { standalone?: boolean }).standalone === true;
  } catch {
    return false;
  }
}

/**
 * Navigate the whole page to Google's OAuth authorize endpoint and come
 * straight back to the app with the token in the URL fragment. Used only in
 * standalone-PWA mode, and only from a real user tap (so the navigation
 * feels expected rather than surprising).
 */
function beginRedirectAuth(clientId: string, promptMode?: 'none' | 'consent', loginHint?: string) {
  const state = generateOAuthState();
  sessionStorage.setItem(REDIRECT_STATE_SESSION_KEY, state);
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: new URL(import.meta.env.BASE_URL, window.location.origin).toString(),
    response_type: 'token',
    scope: OAUTH_SCOPES,
    include_granted_scopes: 'true',
    state,
  });
  if (promptMode) params.set('prompt', promptMode);
  if (loginHint) params.set('login_hint', loginHint);
  window.location.assign(`${OAUTH_AUTH_ENDPOINT}?${params.toString()}`);
}

/** Resolves to `fallback` if `promise` hasn't settled within `ms`. */
function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) { settled = true; resolve(fallback); }
    }, ms);
    promise.then(
      (value) => { if (!settled) { settled = true; clearTimeout(timer); resolve(value); } },
      () => { if (!settled) { settled = true; clearTimeout(timer); resolve(fallback); } },
    );
  });
}

// ── Context ──────────────────────────────────────────────────────────────────

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>({
    user: null,
    isLoading: true,
    isAuthenticated: false,
    authError: null,
    hasDriveAccess: false,
    gisReady: false,
  });

  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined;
  // Tracks an in-flight silent refresh so concurrent callers share one promise
  // instead of firing multiple simultaneous token requests.
  const refreshInFlightRef = useRef<Promise<string | null> | null>(null);
  const tokenRef = useRef<{ token: string; expiresAt: number } | null>(null);
  const requestDriveAndIdentifyRef = useRef<() => void>(() => undefined);
  const [showSignOutChoice, setShowSignOutChoice] = useState(false);
  const [removeDataDefault, setRemoveDataDefault] = useState(false);
  const [signOutBusy, setSignOutBusy] = useState(false);
  const [signOutError, setSignOutError] = useState<string | null>(null);

  const rememberUser = useCallback((user: AppUser) => {
    STORAGE.setItem(SESSION_USER_KEY, JSON.stringify(user));
    STORAGE.setItem(HAD_SESSION_KEY, '1');
  }, []);

  const rememberToken = useCallback((token: string, expiresAt: number) => {
    tokenRef.current = { token, expiresAt };
    setState(s => ({ ...s, hasDriveAccess: true }));
  }, []);

  // Applies a verified token obtained via standalone-PWA redirect.
  const applyTokenResponse = useCallback(async (accessToken: string, expiresAt: number) => {
    try {
      if (!clientId) throw new Error('Google sign-in is not configured.');
      await verifyGoogleAccessToken(accessToken, clientId);
      const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      if (!res.ok) throw new Error('Google user identity could not be loaded.');
      const info = await res.json() as { sub: string; email: string; name: string; picture: string };
      const now = new Date().toISOString();
      const user: AppUser = {
        id: info.sub,
        googleSubjectId: info.sub,
        email: info.email,
        displayName: info.name,
        photoUrl: info.picture,
        createdAt: now,
        updatedAt: now,
      };
      rememberUser(user);
      rememberToken(accessToken, expiresAt);
      sessionStorage.removeItem(AUTO_REAUTH_GUARD_KEY);
      setState(s => ({
        ...s, user, isAuthenticated: true, isLoading: false,
        authError: null,
      }));
    } catch (error) {
      sessionStorage.removeItem(AUTO_REAUTH_GUARD_KEY);
      setState(s => ({
        ...s,
        isLoading: false,
        authError: error instanceof Error && error.message.includes('required app audience')
          ? 'Google sign-in was rejected because the token was not issued for this app or lacks Drive file access.'
          : 'Google sign-in could not be verified. Please try again and approve Drive file access.',
      }));
    }
  }, [clientId, rememberToken, rememberUser]);

  // ── Restore session on mount ─────────────────────────────────────────────

  useEffect(() => {
    // Returning from a standalone-PWA redirect reauth (see beginRedirectAuth
    // above)? The token comes back in the URL fragment rather than a popup
    // callback.
    const hash = window.location.hash;
    if (hash) {
      const expectedState = sessionStorage.getItem(REDIRECT_STATE_SESSION_KEY);
      const redirectResponse = parseOAuthRedirect(hash, expectedState);
      sessionStorage.removeItem(REDIRECT_STATE_SESSION_KEY);
      window.history.replaceState(null, '', window.location.pathname + window.location.search);

      if (redirectResponse.accepted) {
        const accessToken = redirectResponse.accessToken;
        const expiresIn = redirectResponse.expiresIn || DEFAULT_TOKEN_LIFETIME_S;
        if (accessToken) {
          void applyTokenResponse(accessToken, Date.now() + expiresIn * 1000);
          return;
        }
        if (redirectResponse.error) {
          setState(s => ({ ...s, authError: 'Google sign-in was cancelled or could not be completed.' }));
        }
      }
    }

    try {
      const raw = STORAGE.getItem(SESSION_USER_KEY);

      if (raw) {
        const user = JSON.parse(raw) as AppUser;
        STORAGE.setItem(HAD_SESSION_KEY, '1');
        setState(s => ({
          ...s,
          user,
          isAuthenticated: true,
          isLoading: false,
          hasDriveAccess: false,
        }));
        return;
      }
    } catch (error) {
      console.error('[COLLECT-AG] Could not restore the saved sign-in identity:', error);
    }
    setState(s => ({ ...s, isLoading: false }));
  }, [applyTokenResponse]);

  // ── Wait for GIS script then initialise ─────────────────────────────────

  const handleCredential = useCallback((response: GoogleCredentialResponse) => {
    const user = buildUser(response.credential);
    rememberUser(user);
    setState(s => ({ ...s, user, isAuthenticated: true, isLoading: false, authError: null }));
  }, [rememberUser]);

  useEffect(() => {
    if (!clientId) {
      setState(s => ({ ...s, gisReady: false }));
      return;
    }

    let attempts = 0;
    const maxAttempts = 40; // 10 seconds

    const tryInit = () => {
      if (window.google?.accounts?.id) {
        window.google.accounts.id.initialize({
          client_id: clientId,
          callback: handleCredential,
          auto_select: false,
          cancel_on_tap_outside: true,
          ux_mode: 'popup',
        });

        setState(s => ({ ...s, gisReady: true }));
        return;
      }

      attempts++;
      if (attempts < maxAttempts) {
        setTimeout(tryInit, 250);
      }
    };

    tryInit();
  }, [clientId, handleCredential]);

  // ── Sign in ──────────────────────────────────────────────────────────────

  const signIn = useCallback(() => {
    setState(s => ({ ...s, authError: null }));

    const signInAsMockDevUser = () => {
      if (!import.meta.env.DEV) return;
      const mock: AppUser = {
        id: 'dev_user_01',
        email: 'dev@example.test',
        displayName: 'Dev User',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      rememberUser(mock);
      setState(s => ({ ...s, user: mock, isAuthenticated: true, isLoading: false, authError: null }));
    };

    if (!clientId) {
      if (import.meta.env.DEV) {
        signInAsMockDevUser();
      } else {
        setState(s => ({
          ...s,
          authError: 'Google sign-in is not configured. Set VITE_GOOGLE_CLIENT_ID for this deployment.',
        }));
      }
      return;
    }

    // Google's One Tap / popup flows don't reliably work from an installed
    // PWA's standalone window on Android (see the standalone-PWA reauth
    // section above) — go straight to a full-page redirect instead.
    if (isStandalonePWA()) {
      beginRedirectAuth(clientId);
      return;
    }

    if (!state.gisReady) {
      if (import.meta.env.DEV) {
        signInAsMockDevUser();
      } else {
        setState(s => ({ ...s, authError: 'Google sign-in is still loading. Please try again shortly.' }));
      }
      return;
    }

    window.google!.accounts.id.prompt((notification) => {
      if (notification.isNotDisplayed() || notification.isSkippedMoment()) {
        requestDriveAndIdentifyRef.current();
      }
    });
  }, [clientId, state.gisReady, rememberUser]);

  // Fallback: use the OAuth2 token flow to get both identity + Drive token
  const requestDriveAndIdentify = useCallback(() => {
    if (!clientId || !window.google) return;

    const tc = window.google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: [
        'openid',
        'email',
        'profile',
        DRIVE_FILE_SCOPE,
      ].join(' '),
      callback: async (resp: GoogleTokenResponse) => {
        if (resp.error || !resp.access_token) {
          setState(s => ({ ...s, authError: 'Google sign-in failed. Please try again.' }));
          return;
        }

        const expiresAt = Date.now() + (resp.expires_in ?? DEFAULT_TOKEN_LIFETIME_S) * 1000;

        try {
          await verifyGoogleAccessToken(resp.access_token, clientId);
          const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { Authorization: `Bearer ${resp.access_token}` },
          });
          if (!res.ok) throw new Error('Google user identity could not be loaded.');
          const info = await res.json() as {
            sub: string; email: string; name: string; picture: string;
          };
          const now = new Date().toISOString();
          const user: AppUser = {
            id: info.sub,
            googleSubjectId: info.sub,
            email: info.email,
            displayName: info.name,
            photoUrl: info.picture,
            createdAt: now,
            updatedAt: now,
          };
          rememberUser(user);
          rememberToken(resp.access_token, expiresAt);
          setState(s => ({
            ...s,
            user,
            isAuthenticated: true,
            isLoading: false,
            authError: null,
          }));
        } catch (error) {
          setState(s => ({
            ...s,
            authError: error instanceof Error && error.message.includes('required app audience')
              ? 'Google sign-in was rejected because the token was not issued for this app or lacks Drive file access.'
              : 'Google sign-in could not be verified. Please try again and approve Drive file access.',
          }));
        }
      },
    });

    tc.requestAccessToken({ prompt: 'select_account' });
  }, [clientId, rememberToken, rememberUser]);
  requestDriveAndIdentifyRef.current = requestDriveAndIdentify;

  // ── Request Drive access (interactive-capable — used on first grant) ─────

  const requestDriveAccess = useCallback((): Promise<boolean> => {
    if (!clientId || !window.google) {
      if (import.meta.env.DEV) {
        const mockToken = 'dev_token_mock';
        const expiresAt = Date.now() + DEFAULT_TOKEN_LIFETIME_S * 1000;
        rememberToken(mockToken, expiresAt);
        return Promise.resolve(true);
      }
      setState(s => ({
        ...s,
        authError: 'Google Drive is not configured. Set VITE_GOOGLE_CLIENT_ID for this deployment.',
      }));
      return Promise.resolve(false);
    }

    if (isStandalonePWA()) {
      // A popup-based silent refresh can't complete from a standalone PWA
      // window (see note above) — don't attempt it from this non-gesture
      // context. Callers fall back to the "no_drive" / "Connect Drive"
      // state, whose action button calls connectDriveInteractive(), which
      // uses a redirect and works from a real tap.
      return Promise.resolve(false);
    }

    return new Promise((resolve) => {
      const tc = window.google!.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: DRIVE_FILE_SCOPE,
        callback: async (resp: GoogleTokenResponse) => {
          if (resp.error || !resp.access_token) {
            resolve(false);
            return;
          }
          const expiresAt = Date.now() + (resp.expires_in ?? DEFAULT_TOKEN_LIFETIME_S) * 1000;
          try {
            await verifyGoogleAccessToken(resp.access_token, clientId);
            rememberToken(resp.access_token, expiresAt);
            setState(s => ({ ...s, authError: null }));
            resolve(true);
          } catch (error) {
            setState(s => ({
              ...s,
              authError: error instanceof Error && error.message.includes('required app audience')
                ? 'Google sign-in was rejected because the token was not issued for this app or lacks Drive file access.'
                : 'Google Drive access could not be verified. Please try again.',
            }));
            resolve(false);
          }
        },
      });
      // Empty prompt = attempt silently first; Google shows UI only if
      // this app+scope has never been consented to in this browser before.
      tc.requestAccessToken({ prompt: '' });
    });
  }, [clientId, rememberToken]);

  // ── Connect Drive — explicit user action, guarantees a visible outcome ───

  const connectDriveInteractive = useCallback((): Promise<boolean> => {
    if (!clientId || !window.google) {
      if (import.meta.env.DEV) {
        const mockToken = 'dev_token_mock';
        const expiresAt = Date.now() + DEFAULT_TOKEN_LIFETIME_S * 1000;
        rememberToken(mockToken, expiresAt);
        return Promise.resolve(true);
      }
      setState(s => ({
        ...s,
        authError: 'Google Drive is not configured. Set VITE_GOOGLE_CLIENT_ID for this deployment.',
      }));
      return Promise.resolve(false);
    }

    if (isStandalonePWA()) {
      return new Promise((resolve) => {
        try {
          // Deliberately no `prompt: 'consent'` here (unlike the popup path
          // below) — for a returning, already-consented user this lets
          // Google skip straight back with a fresh token instead of forcing
          // the full permission screen every time the app needs to
          // reconnect. First-time users still see the normal picker/consent
          // screen since nothing has been granted yet.
          beginRedirectAuth(clientId, undefined, state.user?.email);
        } catch {
          resolve(false);
          return;
        }
        // We should already be navigating away — this only fires if that
        // somehow didn't happen, so the caller isn't left stuck forever.
        setTimeout(() => resolve(false), 8000);
      });
    }

    return new Promise((resolve) => {
      const tc = window.google!.accounts.oauth2.initTokenClient({
        client_id: clientId,
        scope: DRIVE_FILE_SCOPE,
        callback: async (resp: GoogleTokenResponse) => {
          if (resp.error || !resp.access_token) {
            resolve(false);
            return;
          }
          const expiresAt = Date.now() + (resp.expires_in ?? DEFAULT_TOKEN_LIFETIME_S) * 1000;
          try {
            await verifyGoogleAccessToken(resp.access_token, clientId);
            rememberToken(resp.access_token, expiresAt);
            setState(s => ({ ...s, authError: null }));
            resolve(true);
          } catch (error) {
            setState(s => ({
              ...s,
              authError: error instanceof Error && error.message.includes('required app audience')
                ? 'Google sign-in was rejected because the token was not issued for this app or lacks Drive file access.'
                : 'Google Drive access could not be verified. Please try again.',
            }));
            resolve(false);
          }
        },
      });
      // Explicit user action (a real click) — force a visible consent
      // dialog every time, so the outcome is never ambiguous.
      tc.requestAccessToken({ prompt: 'consent' });
    });
  }, [clientId, state.user, rememberToken]);

  // ── Attempt one automatic, silent reconnect (standalone "app opened" case) ─
  //
  // Called right when the app is opened or resumed from the background,
  // before it tries to sync. If the token expired while the standalone PWA
  // was backgrounded, this proactively starts the redirect-based reauth
  // instead of waiting for the user to notice and tap "Connect Drive"
  // themselves. Deliberately NOT wired into ensureFreshToken/requestDriveAccess
  // (called from the 5-min background timer too) — redirecting the whole app
  // away mid-interaction would be jarring; only "app open" moments do this.
  // Runs at most once per tab session (AUTO_REAUTH_GUARD_KEY) so a session
  // that's truly gone (revoked, signed out elsewhere) falls back to the
  // manual button instead of redirect-looping. Returns true if a redirect
  // was started (caller should stop, since the page is about to unload).

  const attemptSilentReconnect = useCallback((): boolean => {
    if (!clientId || !isStandalonePWA()) return false;
    if (sessionStorage.getItem(AUTO_REAUTH_GUARD_KEY)) return false;

    if (tokenRef.current && isTokenValid(tokenRef.current.expiresAt)) return false;

    const storedUserRaw = STORAGE.getItem(SESSION_USER_KEY);
    if (!storedUserRaw || STORAGE.getItem(HAD_SESSION_KEY) !== '1') return false;

    let email: string | undefined;
    try { email = (JSON.parse(storedUserRaw) as AppUser).email; } catch { /* ignore */ }

    sessionStorage.setItem(AUTO_REAUTH_GUARD_KEY, '1');
    beginRedirectAuth(clientId, 'none', email);
    return true;
  }, [clientId]);

  // ── Ensure a fresh token — the function nearly everything should call ────

  const ensureFreshToken = useCallback((): Promise<string | null> => {
    const currentToken = tokenRef.current;
    if (currentToken && isTokenValid(currentToken.expiresAt)) {
      return Promise.resolve(currentToken.token);
    }

    // Share one in-flight refresh across concurrent callers
    if (refreshInFlightRef.current) return refreshInFlightRef.current;

    // Bound the wait: if a popup silently fails to open/complete (blocked,
    // or an opener-less standalone-PWA window), don't let this hang forever
    // and wedge every future call behind the same stuck promise.
    const refreshPromise = withTimeout(requestDriveAccess(), 15000, false)
      .then(granted => (granted ? tokenRef.current?.token ?? null : null))
      .finally(() => { refreshInFlightRef.current = null; });

    refreshInFlightRef.current = refreshPromise;
    return refreshPromise;
  }, [requestDriveAccess]);

  // ── Sign out ─────────────────────────────────────────────────────────────

  const finishSignOut = useCallback(async (removeLocalData: boolean) => {
    setSignOutBusy(true);
    setSignOutError(null);
    const token = tokenRef.current?.token;
    if (token && token !== 'dev_token_mock') {
      try {
        const revoke = window.google?.accounts.oauth2.revoke;
        if (revoke) {
          revoke(token, () => undefined);
        } else {
          void fetch('https://oauth2.googleapis.com/revoke', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ token }),
          }).then(response => {
            if (!response.ok) console.error('[COLLECT-AG] Google token revocation failed.');
          }).catch(error => {
            console.error('[COLLECT-AG] Google token revocation failed:', error);
          });
        }
      } catch (error) {
        console.error('[COLLECT-AG] Google token revocation could not be started:', error);
      }
    }

    sessionStorage.removeItem(AUTO_REAUTH_GUARD_KEY);
    sessionStorage.removeItem(REDIRECT_STATE_SESSION_KEY);
    if (clientId && window.google?.accounts?.id) {
      window.google.accounts.id.disableAutoSelect();
      window.google.accounts.id.cancel();
    }

    try {
      await finalizeSignOut(removeLocalData);
      setShowSignOutChoice(false);
    } catch (error) {
      console.error('[COLLECT-AG] Could not remove local database during sign-out:', error);
      setSignOutError('You are signed out, but local data could not be removed. Please try removing it again.');
    } finally {
      tokenRef.current = null;
      setState(s => ({
        ...s,
        user: null,
        isLoading: false,
        isAuthenticated: false,
        authError: null,
        hasDriveAccess: false,
      }));
      setSignOutBusy(false);
    }
  }, [clientId]);

  const signOut = useCallback(async (removeLocalData?: boolean) => {
    if (typeof removeLocalData === 'boolean') {
      await finishSignOut(removeLocalData);
      return;
    }

    setSignOutError(null);
    try {
      const meta = await driveMetaRepository.get();
      setRemoveDataDefault(!!meta.lastRemotePushAt);
    } catch (error) {
      console.error('[COLLECT-AG] Could not check the last successful Drive push:', error);
      setRemoveDataDefault(false);
      setSignOutError('Could not check whether your latest changes were synced. Choose whether to remove local data.');
    }
    setShowSignOutChoice(true);
  }, [finishSignOut]);

  return (
    <AuthContext.Provider
      value={{
        ...state, signIn, signOut, requestDriveAccess,
        connectDriveInteractive, attemptSilentReconnect, ensureFreshToken,
      }}
    >
      {children}
      {showSignOutChoice && (
        <div
          role="presentation"
          style={{
            position: 'fixed', inset: 0, zIndex: 10000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: 20, background: 'rgba(0,0,0,0.55)',
          }}
        >
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="sign-out-title"
            style={{
              width: 'min(100%, 440px)', padding: 24,
              borderRadius: 16, background: 'var(--color-white)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
            }}
          >
            <h2 id="sign-out-title" style={{ fontSize: 20, marginBottom: 10, color: 'var(--color-ink)' }}>
              Sign out
            </h2>
            <p style={{ fontSize: 14, lineHeight: 1.6, color: 'var(--color-charcoal)', marginBottom: 16 }}>
              Remove data from this device too? Your Google Drive data will not be affected.
            </p>
            {signOutError && (
              <p role="alert" style={{ color: '#b91c1c', fontSize: 13, marginBottom: 14 }}>
                {signOutError}
              </p>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, flexWrap: 'wrap' }}>
              {signOutError && !state.isAuthenticated ? (
                <>
                  <button className="btn-secondary" onClick={() => setShowSignOutChoice(false)}>
                    Dismiss
                  </button>
                  <button className="btn-primary" disabled={signOutBusy} onClick={() => void finishSignOut(true)}>
                    {signOutBusy ? 'Removing…' : 'Retry data removal'}
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="btn-secondary"
                    disabled={signOutBusy}
                    autoFocus={!removeDataDefault}
                    onClick={() => void finishSignOut(false)}
                  >
                    Keep data &amp; sign out
                  </button>
                  <button
                    className="btn-primary"
                    disabled={signOutBusy}
                    autoFocus={removeDataDefault}
                    onClick={() => void finishSignOut(true)}
                  >
                    {signOutBusy ? 'Signing out…' : 'Remove data &amp; sign out'}
                  </button>
                </>
              )}
            </div>
          </section>
        </div>
      )}
    </AuthContext.Provider>
  );
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
